$(document).ready(function() {
	$('#page-alarm-btn-home').click(function() {
		document.location.href = 'index.html';
	});
});